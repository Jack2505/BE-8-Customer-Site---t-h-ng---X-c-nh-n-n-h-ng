using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using OrderSite.Models;
namespace OrderSite.Controllers
{
    public class OrderController : Controller
    {
        [HttpGet]
        public ActionResult Checkout()
        {
            var items = Session["OrderCart"] as List<OrderItemVM>;
            if (items == null || !items.Any()) return RedirectToAction("Index", "Home");
            return View(new OrderVM { Items = items, Total = items.Sum(x => x.TotalPrice), DeliveryMethod = "Giao hàng tiêu chuẩn", PaymentMethod = "Thanh toán khi nhận hàng" });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Checkout(OrderVM model)
        {
            var items = Session["OrderCart"] as List<OrderItemVM>;
            if (items == null || !items.Any()) return RedirectToAction("Index", "Home");
            model.Items = items;
            model.Total = items.Sum(x => x.TotalPrice);
            if (!ModelState.IsValid) return View(model);
            model.OrderID = new Random().Next(10000, 99999);
            model.OrderDate = DateTime.Now;
            model.PaymentStatus = model.PaymentMethod == "Thanh toán khi nhận hàng" ? "Chờ thanh toán" : "Chưa thanh toán";
            Session["CompletedOrder"] = model;
            Session["OrderCart"] = null;
            return RedirectToAction("OrderSuccess");
        }

        public ActionResult OrderSuccess()
        {
            var model = Session["CompletedOrder"] as OrderVM;
            if (model == null) return RedirectToAction("Index", "Home");
            return View(model);
        }
    }
}
