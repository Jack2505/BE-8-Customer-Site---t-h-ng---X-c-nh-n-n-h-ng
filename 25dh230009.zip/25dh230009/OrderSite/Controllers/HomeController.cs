using System.Collections.Generic;
using System.Web.Mvc;
using OrderSite.Models;
namespace OrderSite.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            if (Session["OrderCart"] == null)
            {
                Session["OrderCart"] = new List<OrderItemVM>
                {
                    new OrderItemVM { ProductName = "Tai nghe Bluetooth", Quantity = 1, UnitPrice = 350000 },
                    new OrderItemVM { ProductName = "Bàn phím cơ", Quantity = 1, UnitPrice = 690000 },
                    new OrderItemVM { ProductName = "Chuột không dây", Quantity = 2, UnitPrice = 180000 }
                };
            }
            return View(Session["OrderCart"] as List<OrderItemVM>);
        }
    }
}
